<img width="1361" height="717" alt="Screenshot 2025-09-29 195701" src="https://github.com/user-attachments/assets/7cdb89f1-4377-4ace-a25c-6eaab70820d8" />
